import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, Image } from 'react-native';


export default function Login({ navigation }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = () => {
    if (username.trim() === '' || password.trim() === '') {
      alert('Por favor completa todos los campos.');
      return;
    }
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUsername('');
    setPassword('');
  };

  const handleGoogleLogin = () => {
    console.log('Login with Google');
  };

  const handleGitHubLogin = () => {
    console.log('Login with GitHub');
  };

  const handleRegisterRedirect = () => {
    navigation.navigate('Register');
  };

  const [values, setValues] = React.useState({
    password: "",
    showPassword: false,
  });



  return (
    <View style={styles.container}>
      {isLoggedIn ? (
        <View>
          <Text>Bienvenido, {username}!</Text>
          <TouchableOpacity style={styles.button} onPress={handleLogout}>
            <Text style={styles.buttonText}>Comenzar</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <View>
          <Text style={styles.headerText}>¡Bienvenido de nuevo!</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your email"
            value={username}
            onChangeText={setUsername}
            autoCapitalize="none"
          />
          <TextInput
            style={styles.input}
            placeholder="Enter your password"
            secureTextEntry
            value={password}
            onChangeText={setPassword}
            autoCapitalize="none"
          />

          <TouchableOpacity onPress={handleLogin}>
            <Text style={styles.forgetText}>Olvidaste tu contraseña?</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.button} onPress={handleLogin}>
            <Text style={styles.buttonText}>Login</Text>
          </TouchableOpacity>

          <Text style={styles.TextUnderLogin}>or continue with</Text>

          <TouchableOpacity style={[styles.button, styles.googleButton]} onPress={handleGoogleLogin}>
            <View style={styles.buttonContent}>
              <Image source={require('C:/Users/blasi/Class/assets/google.png')} style={styles.buttonIcon} />
              <Text style={[styles.buttonText, { color: '#000' }]}>Google</Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.button, styles.githubButton]} onPress={handleGitHubLogin}>
            <View style={styles.buttonContent}>  
              <Image source={require('C:/Users/blasi/Class/assets/github.png')} style={styles.buttonIcon} />
              <Text style={[styles.buttonText, { color: '#000' }]}>GitHub</Text>
            </View>
          </TouchableOpacity>
          <View style={styles.dividerContainer}>
            <View style={styles.divider} />
          </View>
          <View style={styles.registerContainer}>
            <Text style={styles.registerText}>Aún no has creado una cuenta?</Text>
            <TouchableOpacity style={styles.registerButton} onPress={handleRegisterRedirect}>
              <Text style={styles.registerButtonText}>Sign up</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    fontFamily:  "Poppins", 
    backgroundColor: '#EFEDEC',
    alignItems: 'center',
    fontFamily: 'Poppins',
    padding:40,
  },

  headerText:{
    marginBottom: 30,
    fontSize: 24,
    color: '#333232',
    fontWeight: 'bold',
    width: 160,
  },

  input: {
    height: 55,
    width: 300,
    borderColor: '#333232',
    borderWidth: 1,
    marginBottom: 22,
    paddingHorizontal: 10,
    borderRadius: 25,
  },

  button: {
    backgroundColor: '#333232',
    height: 55,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
    width: 300,
    marginTop: 7,
    marginBottom: 3,
  },

  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    
  },

  forgetText:{
    textAlign: 'right',
    paddingBottom: 20,
    fontSize: 13,
    fontWeight: 'bold',
  },

  TextUnderLogin:{
    margin: 20,
    textAlign: 'center',
    alignContent: 'center',
    justifyContent: 'center', 
    fontSize: 12,
  },

  googleButton: {
    backgroundColor: '#EFEDEC',
    borderWidth: 1,
    borderColor: 'black',
    marginBottom: 10,
  },
  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
  },
  buttonIcon: {
    width: 20,
    height: 20,
    marginRight:10,
  },
  githubButton: {
    backgroundColor: '#EFEDEC',
    borderWidth: 1,
    borderColor: 'black',
  },
  dividerContainer: {
    width: '100%',
    alignItems: 'center',
  },
  divider: {
    height: 1,
    backgroundColor: 'gray',
    width: '80%',
    marginVertical: 20,
  },
  registerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
  },
  registerText: {
    marginRight: 0,
    color: 'black',
  },
  registerButton: {
    padding: 8,
    borderRadius: 5,
  },
  registerButtonText: {
    color: '#333232',
    fontWeight:'bold',
  },
});
